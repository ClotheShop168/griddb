var popup = '<div class="popup"></div>';
$(document).ready(function(){
    // click to change form 
    $('.btn-login').click(function(){
        $(this).addClass('active-bg');
        $('.btn-register').removeClass('active-bg');
        $('.header #head-2 , .login-frm').css({'display':'block'});
        $('.header #head-1 , .register-frm').css({'display':'none'});
    });
    $('.btn-register').click(function(){
        $(this).addClass('active-bg');
        $('.btn-login').removeClass('active-bg');
        $('.header #head-1 , .register-frm').css({'display':'block'});
        $('.header #head-2 , .login-frm').css({'display':'none'});
    });
    // click to popup form
    $('.login').click(function(){
        // lock scrolling bar
        $html = $('html'); 
        $body = $('body'); 
        var initWidth = $body.outerWidth();
        var initHeight = $body.outerHeight();

        var scrollPosition = [
            self.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft,
            self.pageYOffset || document.documentElement.scrollTop  || document.body.scrollTop
        ];
        $html.data('scroll-position', scrollPosition);
        $html.data('previous-overflow', $html.css('overflow'));
        $html.css('overflow', 'hidden');
        window.scrollTo(scrollPosition[0], scrollPosition[1]);   

        var marginR = $body.outerWidth()-initWidth;
        var marginB = $body.outerHeight()-initHeight; 
        $body.css({'margin-right': marginR,'margin-bottom': marginB});
        // show form
        $('.popup-form').css({'visibility':'visible'});
    });
    // click to close popup form
    $('.btnClose').click(function(){
        // unlock scroll bar
        $html = $('html');
        $body = $('body');
        $html.css('overflow', $html.data('previous-overflow'));
        var scrollPosition = $html.data('scroll-position');
        window.scrollTo(scrollPosition[0], scrollPosition[1]);    

        $body.css({'margin-right': 0, 'margin-bottom': 0});
        // close form
        $('.popup-form').css({'visibility':'hidden'});
    });
    // change background color
    $('.ch-color .fa-moon').click(function(){
        $('.ch-color .fa-sun').removeClass('active-color');
        $(this).addClass('active-color');
        $('body').css({'background-color':'black'});
        $('.onscroll').css({'background-color':'white','color':'black'})
    });
    $('.ch-color .fa-sun').click(function(){
        $('.ch-color .fa-moon').removeClass('active-color');
        $(this).addClass('active-color');
        $('body').css({'background-color':'white'});
        $('.onscroll').css({'background-color':'black','color':'white'})
    });
    // onscroll top 
    $('.onscroll').click(function(){
       $('html,body').scrollTop({behaivor:'smooth'});
    });
    // slide 
    var slide = $('.slide');
    var numSlide = slide.length;// 5
    slide.hide();
    var x = 0;
    slide.eq(x).show();
    //btn-next 
    $('.btn-next').click(function(){
        slide.eq(x).hide();
        $('.pageSlide ul').find('li').eq(x).removeClass('active');
        x++; // x = x+1;
        if(x >= numSlide){
            x = 0;
        }
        slide.eq(x).show();
        $('.pageSlide ul').find('li').eq(x).addClass('active');
    });
    //btn-prev
    $('.btn-prev').click(function(){
        slide.eq(x).hide();
        $('.pageSlide ul').find('li').eq(x).removeClass('active');
        if(x == 0){
            x = numSlide;
        }
        x--;
        slide.eq(x).show();
        $('.pageSlide ul').find('li').eq(x).addClass('active');
    });
    // Get page slide
    get_pageSlide();
    function get_pageSlide(){
        var li = ' ';
        for(var i = 0; i < numSlide; i++){
            x++;// 1 2 
            li += '<li> </li>';
        }
        $('.pageSlide ul').html(li);
        $('.pageSlide ul').find('li').eq(0).addClass('active');
    }
    //click change page slide
    $('.pageSlide ul').on('click','li',function(){
        slide.eq(x).hide();
        $('.pageSlide ul').find('li').eq(x).removeClass('active');
        x = $(this).index();
        slide.eq(x).show();
        $('.pageSlide ul').find('li').eq(0).addClass('active');
    });
    // left-menu
    $("li").click(function(){

        var num = $(this).find(".h").length
    
        if(num == 1){
        $(this).parent().find('li .subMenu').slideUp();
        $(this).find('.subMenu').slideDown()
        $(this).find('.h').removeClass('h');
        
        }else{
        $(this).parent().find('li .subMenu').slideUp();
        $(this).find('.subMenu').slideUp()
        $(this).find('.clickdown').addClass('h');
        }

    })
    //drop down
    var menuBox2 = {
        "Apple":["iPhone","Macbook","iPad"],
        "Google":["Google","Drive","Google Map"],
        "Microsoft":["Window","Office","Firebase"],
        "Meta":["FaceBook","Instargram","Messenger"],
        "Asus":["ROG","ROG Phone","Tuf"]
    };
    getMenu2();
    function getMenu2(){
        var txt='';
        for(var keys in menuBox2){
            var txt2='';
            var subMenuData = menuBox2[keys];
            for(var i in subMenuData){
                txt2 +='<li><a href="">'+subMenuData[i]+'</a></li>';
            }
            var subMenu = '<div class="sub-menu"><ul>'+txt2+'</ul></div>';
            txt += '<li><a href="">'+keys+'</a>'+subMenu+'</li>';
        }
        $('.menu ul').append(txt);
    }
    //-------
    var menuBox = [
        {name:"Home"},
        {name:"Sport"},
        {name:"News"},
        {name:"Contact"},
        {name:"FeedBack"}
    ];
    getMenu();  
    function getMenu(){
        var txt = '';
        for(var key in menuBox){
            txt+='<li><a href="#">'+menuBox[key].name+'</a></li>';
        }
        // $('.menu ul').append(txt);
        $('.popMenu ul').html(txt);
    }
    $('#btnMenu').click(function(){
        $('body').append(popup);
        $('.popMenu').css({'left':'0px'});
    });
    $('body').on('click','.popup',function(){
        $(this).remove();
        $('.popMenu').css({'left':'-285px'});
    })
});